# MathPath: AI Math Differentiator

A simple interactive website for differentiated learning in mathematics, focused on linear equations.

## Features
- Three difficulty levels: Foundation, Standard, and Advanced
- Practice tasks with answer checking
- Hints and step-by-step solutions
- Responsive layout for phones and computers

## How to use
Open `index.html` in a web browser. The demo uses built-in practice tasks; it does not call a live AI API.

## Deployment
This static site can be published using GitHub Pages or Netlify by uploading the contents of this folder.

## Project topic
AI for Differentiated Learning.
